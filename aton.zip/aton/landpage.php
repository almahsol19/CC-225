<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    body{
        margin: 0;
        padding: 0;
        justify-content: center;
        background-color: rgb(140, 147, 180);
    }
    .big-container{
        display: flex;    
        justify-content: center;
        align-items: center;        
        height: 100vh;      
        width : 100vw;          
    }                            

    .container{
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content:center;
        height: 50vh;
        width: 50vh;
        border-radius: 10px;
        background-color: rgb(190, 193, 206);
    }
    .group{
        display: flex;
        flex-direction: column;
        margin: 5px;
    }
    .group label{
        margin: 5px;
    }
    .group input{
        margin: 5px;
        border-radius: 5px;
    }
    #signup{
        margin: 7px;
        border-radius: 5px;
        background-color: rgb(118, 119, 120);
    }
    #login{
        margin: 7px;
        border-radius: 5px;
        background-color: rgb(118, 119, 120);
    }
</style>
<body>
    <div class="big-container">
        <div class="container">
            <!-- Form will submit to the same page for processing -->
            <form action="" method="POST">
                <div class="group">
                    <label for="name">Username:</label>
                    <input type="text" id="name" name="Username" required>
                </div>
                <div class="group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="Password" required>   
                </div>
                <div class="button-group">
                    <button id="signup" type="button" name="signup" onclick="goToSignup()">Sign Up</button>
                    <script>
                        function goToSignup(){   
                            window.location.href = "signup.php";
                        }
                    </script>
                    <button id="login" type="submit" name="login">Login</button>
                </div>
            </form>

            <?php
            // Process the login form submission
            if (isset($_POST['login'])) {
                // Capture form data
                $username = $_POST['Username'];
                $password = $_POST['Password'];

                // Create a connection to the database
                $conn = new mysqli('localhost', 'root', '', 'dhas');

                // Check for connection errors
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Use prepared statements to prevent SQL injection
                $stmt = $conn->prepare("SELECT * FROM username WHERE Username = ? AND password = ?");
                $stmt->bind_param('ss', $username, $password);
                
                // Execute the statement
                $stmt->execute();

                // Store the result
                $result = $stmt->get_result();

                // Check if a matching record is found
                if ($result->num_rows > 0) {
                    // If login is successful, redirect to welcome.php
                    header("Location: welcome.php");
                    exit();
                } else {
                    // If login fails, show an error message
                    echo "<script>alert('Invalid username or password!');</script>";
                }

                // Close the statement and connection
                $stmt->close();
                $conn->close();
            }
            ?>
        </div>
    </div>
</body>
</html>
