<?php
include 'connection.php';
include 'landpage.php';

$conn = OpenCon();

if($conn instanceof mysqli){    
    echo"Connected to mysqli";
}else{  
    echo"Connection failed";
}
CloseCon($conn);
?>