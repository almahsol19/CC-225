<?php
$servername = "localhost";  // Database server, usually 'localhost'
$username = "root";         // Your database username (default is usually 'root')
$password = "";             // Your database password (leave empty for default on localhost)
$dbname = "dhas";  // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    if (isset($_POST['signup'])) {
        $name = $_POST['Username'];
        $password = $_POST['Password'];
        $confirm_password = $_POST['ConfirmPassword'];

        if ($password !== $confirm_password) {
            echo "<script>alert('Passwords do not match!'); window.location.href = 'landpage.php';</script>";
            exit();
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $check_username_query = "SELECT * FROM username WHERE Username = ?";
        $stmt = $conn->prepare($check_username_query);
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Username already exists!'); window.location.href = 'landpage.php';</script>";
        } else {
            $insert_query = "INSERT INTO username (Username, Password) VALUES (?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param('ss', $name, $hashed_password);
            $stmt->execute();

            echo "<script>alert('Registration successful!'); window.location.href = 'welcome.php';</script>";
        }

        $stmt->close();
        CloseCon($conn);
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
</head>
<style>
    body {
        margin: 0;
        padding: 0;
        justify-content: center;
        background-color: rgb(140, 147, 180);
    }
    .big-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        width: 100vw;
    }

    .container {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        height: 50vh;
        width: 50vh;
        border-radius: 10px;
        background-color: rgb(190, 193, 206);
    }

    .group {
        display: flex;
        flex-direction: column;
        margin: 5px;
    }

    .group label {
        margin: 5px;
    }

    .group input {
        margin: 5px;
        border-radius: 5px;
    }

    #signup {
        margin-left: 5px;
        border-radius: 5px;
    }
    #login {
        margin: 5px;
        border-radius: 5px;
    }
</style>
<body>
    <div class="big-container">
        <div class="container">
            
            <form action="signup.php" method="POST">
                <div class="group">
                    <label for="name">Enter Name:</label>
                    <input type="text" id="name" name="Username" required>
                </div>

                <div class="group">
                    <label for="password">Enter Password:</label>
                    <input type="password" id="password" name="Password" required> 
                </div>

                <div class="group">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" id="confirm_password" name="ConfirmPassword" required> 
                </div>

                <div class="button-group">
                    <button id="signup" type="submit" name="signup">Sign Up</button>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
